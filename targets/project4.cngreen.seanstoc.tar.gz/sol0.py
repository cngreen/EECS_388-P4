print "cngreen" + "\x00"*3 + "A+"
